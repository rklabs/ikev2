/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * Copyright (C) 2014 Raju Kadam <rajulkadam@gmail.com>
 *
 * IKEv2 is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * IKEv2 is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "timer.hh"

namespace Timer {

AsyncTimer::AsyncTimer() : stopThread_(false) {
    TRACE();
}

int
AsyncTimer::timerLoop() {
    TRACE();
    while (true) {
        // Block till queue is empty
        {
            std::unique_lock<std::mutex> lock(emptyQMutex_);
            emptyQCond_.wait(lock, [this]{ return this->stopThread_ ||
                                           !this->eventQ_.empty(); });
        }

        if (stopThread_) {
            LOG(INFO, "Timer loop has been stopped");
            return 0;
        }

        Event event;
        if (!eventQ_.empty()) {
            std::unique_lock<std::mutex> lock(timerQMutex_);
            auto elapsedTime = \
                std::chrono::duration_cast<std::chrono::milliseconds>( \
                std::chrono::system_clock::now() - event.startTime_).count();
            // If timeout_ value has been reached trigger handler
            if (elapsedTime >= eventQ_.back().timeLeft_) {
                ENQUEUE_TASK(eventQ_.back().eventHandler_);
                if (!eventQ_.back().repeat_) {
                    LOGT("popped");
                    eventQ_.pop_back();
                } else {
                    LOGT("again");
                    eventQ_.back().startTime_ = std::chrono::system_clock::now();
                    eventQ_.back().timeLeft_ = eventQ_.back().timeout_;
                    std::sort(eventQ_.begin(),
                              eventQ_.end(),
                              [](Event e1, Event e2) {
                                  return e1.timeLeft_ > e2.timeLeft_; });
                }
            } else {
                auto d = std::chrono::duration_cast<std::chrono::milliseconds>( std::chrono::system_clock::now() - eventQ_.back().startTime_);
                eventQ_.back().timeLeft_ = eventQ_.back().timeout_ - d.count();
                timerQCond_.wait_until(lock, std::chrono::system_clock::now() + std::chrono::milliseconds(eventQ_.back().timeLeft_), [this] {
                                          return this->stopThread_; });

            }
        }
    }
}

int
AsyncTimer::cancel(int id) {
    TRACE();

    std::unique_lock<std::mutex> lock(timerQMutex_);
    auto event = std::find_if(eventQ_.begin(),
                              eventQ_.end(),
                              [&](Event e1) { return e1.id_ == id; });

    if (event != eventQ_.end()) {
        eventQ_.erase(event);
        return 0;
    }

    return -1;
}

AsyncTimer &
AsyncTimer::getAsyncTimer() {
    TRACE();
    static AsyncTimer asyncTimer;
    return asyncTimer;
}

void AsyncTimer::shutdown() {
    TRACE();
    stopThread_ = true;
    timerQCond_.notify_all();
    emptyQCond_.notify_all();
}

AsyncTimer::~AsyncTimer() {
    TRACE();
    stopThread_ = true;
    timerQCond_.notify_all();
    emptyQCond_.notify_all();
}

}
